const express = require("express");
const bodyParser = require("body-parser");
const axios = require("axios");
const path = require("path");

const app = express();
const BOT_TOKEN = "7653645214:AAF2HEycMb87XwMtysljzWp0lhuI0WgCbg0"; // token bot Telegram
const ADMIN_CHAT_ID = "6030982150"; // chat_id admin Telegram
const TELEGRAM_API = `https://api.telegram.org/bot${BOT_TOKEN}`;
const pendingVotes = {};

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.get("/", (req, res) => {
  res.send("Bot bình chọn đã chạy!");
});

app.get("/vote", (req, res) => {
  res.sendFile(path.join(__dirname, "form.html"));
});

app.post("/vote", async (req, res) => {
  const { phone, choice } = req.body;
  const voteId = `${phone}_${Date.now()}`;
  pendingVotes[voteId] = res;

  await axios.post(`${TELEGRAM_API}/sendMessage`, {
    chat_id: ADMIN_CHAT_ID,
    text: `Bình chọn mới:
SĐT: ${phone}
Lựa chọn: ${choice}

Trả lời: "${voteId} có" hoặc "${voteId} không"`
  });
});

app.post("/", async (req, res) => {
  const message = req.body.message;
  if (message && message.text && String(message.chat.id) === ADMIN_CHAT_ID) {
    const [voteId, answer] = message.text.trim().split(" ");
    const response = pendingVotes[voteId];

    if (response) {
      if (answer.toLowerCase() === "có") {
        response.send("Bình chọn thành công!");
      } else {
        response.send("Bình chọn không hợp lệ, vui lòng thử lại.");
      }
      delete pendingVotes[voteId];
    }
  }
  res.sendStatus(200);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log("Bot bình chọn đang chạy trên cổng", PORT);
});
